import os, shutil
from pathlib import Path
import pytest
from deepdiff import DeepDiff

from helpers import assertion_messages
from fsa import fsa_utils
from qa_ws_api_utils import projects_utils, ws_api_requests_utils
from qa_utils import files_content_utils
from general_tools import general_tools, general_plugin_tools
import platform


class cfg():
    project_token = ''
    product_token = ''
    product_name: str = 'WST_756'
    project_name: str = 'WST_756'
    invocation_line = ''  # This test defines the invocation line in "runtime"
    expected_names: list = ['github.com/astaxie/beego-053a075344c118a5cc41981b29ef612bb53d20ca'
                            , 'github.com/eladSalti/go_test-t'
                            , 'github.com/eRez-ws/go-stringUtil'
                            , 'github.com/garyburd/redigo-569eae59ada904ea8db7a225c2b47165af08735a'
                            , 'github.com/google/go-querystring-44c6ddd0a2342c386950e880b658017258da92fc']
    expected_libs: int = 5
    path_to_go_project = ''


# Markers
@pytest.mark.testrail_id('2221')
@pytest.mark.go
@pytest.mark.gogradle
@pytest.mark.usefixtures("fsa_env")
class TestWST756:
    """
        WST_756: FSA run on simple GoGradle project.
    """

    def before(self, fsa_env, static_paths):
        os.chdir(str(Path(__file__).resolve().parent))
        cfg.product_token = general_tools.prepare_product(fsa_env['api_url'], fsa_env['organization_token'],
                                                          cfg.product_name, fsa_env['user_id'])

        files_content_utils.update_config_file(fsa_utils.get_default_fsa_config_filename(),
                                               fsa_utils.get_default_fsa_config_keys_values(fsa_env))

        # Set the path to the folder of the go project
        cfg.path_to_go_project = os.path.join(static_paths['go_projects'][platform.system()], cfg.project_name)

        # Remove the folder if exists
        if (os.path.exists(cfg.path_to_go_project)):
            shutil.rmtree(cfg.path_to_go_project)

        # Copy the folder from the data to the external go project
        shutil.copytree(os.path.join(os.getcwd(), 'Data', cfg.project_name), cfg.path_to_go_project)

    @pytest.fixture()
    def before_and_after(self, fsa_env, static_paths):
        self.before(fsa_env, static_paths)

    def test_run(self, static_paths, fsa_env, before_and_after):
        # Define the invocation line
        cfg.invocation_line = ['-d', cfg.path_to_go_project]

        # Run FSA
        fsa_output = fsa_utils.run_fsa(static_paths['path_to_fsa_jar'], cfg.invocation_line)

        # Extract the support token
        support_token = general_plugin_tools.extract_support_token('fsa', fsa_output)

        # Wait until the project update is finished
        ws_api_requests_utils.wait_until_request_is_finished(fsa_env['api_url'], fsa_env['organization_token'],
                                                             support_token)
        # Get the project token
        cfg.project_token = projects_utils.get_project_token_by_name(fsa_env['api_url'], cfg.product_token, 'WST_756')

        # Assert the project token is not empty (In other words, there is a project with the expected name under that product)
        assert cfg.project_token != '', assertion_messages.project_does_not_exist_under_product_error_message(
            cfg.project_name, cfg.product_name)

        # Get the actual libraries
        actual_libraries = projects_utils.get_project_binary_and_source_library_names(fsa_env['api_url'],
                                                                                      cfg.project_token)

        # Assert the num of libraries
        assert len(actual_libraries) == cfg.expected_libs, assertion_messages.num_of_libs_assert(cfg.project_name,
                                                                                                 cfg.expected_libs,
                                                                                                 len(actual_libraries))

        # Assert names
        name_diff = DeepDiff(actual_libraries, cfg.expected_names, ignore_order=True)
        assert name_diff == {}, assertion_messages.generic_diff_error_message(cfg.project_name, 'libraries names',
                                                                              name_diff)
